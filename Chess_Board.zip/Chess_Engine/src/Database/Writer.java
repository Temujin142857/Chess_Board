package Database;

public class Writer {
}
