package Chess_Set;

public class NotAPawnException extends Exception{
    public NotAPawnException(String s){
        super(s);
    }
}
